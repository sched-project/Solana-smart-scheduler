
# Solana Smart Scheduler

A smart transaction scheduling system that helps optimize Solana gas fees by predicting network congestion and scheduling transactions for the best possible time.

## Features

- Real-time Solana gas fee estimation.
- Prediction of the best time to send or schedule a transaction.
- Easily integrable into your Solana dApp.

## Installation

1. Clone this repository:
   ```bash
   git clone https://github.com/yourusername/solana-smart-scheduler.git
   cd solana-smart-scheduler
   ```

2. Install the dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file in the root directory by copying `.env.example`:
   ```bash
   cp .env.example .env
   ```

4. Add your **Helius API Key** and **CoinGecko API Key** to the `.env` file.

## Usage

Import the SDK in your project and use the `getCurrentSolanaStats()` function:

```javascript
const { getCurrentSolanaStats } = require('solana-smart-scheduler');

const heliusApiKey = process.env.HELIUS_API_KEY;
const coingeckoApiKey = process.env.COINGECKO_API_KEY;

getCurrentSolanaStats(heliusApiKey, coingeckoApiKey)
  .then((data) => {
    console.log('Solana Stats:', data);
  })
  .catch((err) => {
    console.error('Error:', err);
  });
```

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
